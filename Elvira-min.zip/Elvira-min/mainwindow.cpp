#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QSettings>
#include <QFile>
#include <QJsonDocument>
#include <QJsonObject>
#include <QJsonArray>
#include <QComboBox>
#include <QMap>
#include <QSlider>
#include <QLabel>
#include <QPushButton>
#include <QMessageBox>
#include <QTimer>



QString MainWindow::getJsonFilePathFromConfig()
{
    QString configFilePath = "./config.ini";

    if (!QFile::exists(configFilePath)) {
        QMessageBox::critical(this, "Errore", "Il file di configurazione config.ini non esiste!");
        QTimer::singleShot(5, this, &QMainWindow::close);
        return "";
    }

    QSettings settings(configFilePath, QSettings::IniFormat);
    settings.beginGroup("Settings");
    QString filepath = settings.value("file_path", "").toString().trimmed();
    settings.endGroup();

    if (filepath.isEmpty()) {
        QMessageBox::critical(this, "Errore", "Il campo non è corretto o non è presente nel file di configurazione, controlla se si chiami 'file_path'!");
        QTimer::singleShot(5, this, &QMainWindow::close);
        return "";
    }

    return filepath;
}

namespace IPFlow {
enum enumLib {
    Version_402 = 402,
};
}

typedef struct struct_Param
{
    IPFlow::enumLib enVersion = IPFlow::Version_402;

    int32_t lParam_100 = 100;
    int32_t lParam_101 = 100;
    int32_t lParam_102 = 40;
    int32_t lParam_103 = 50;
    int32_t lParam_104 = 0;
    int32_t lParam_105 = 100;
    int32_t lParam_106 = 50;
    int32_t lParam_107 = 50;
    int32_t lParam_108 = 50;
    int32_t lParam_400 = 0;
    int32_t lParam_401 = 0;
    int32_t lParam_402 = 0;
    int32_t lParam_403 = 0;
    int32_t lParam_404 = 0;
    int32_t lParam_209 = 0;
    int32_t lParam_700 = 0;
    int32_t lParam_701 = 65535;
    int32_t lParam_702 = 0;
    int32_t lParam_703 = 65535;
    int32_t lParam_710 = 0;
} strParam;


QMap<QString, QJsonObject> m_mapImgs;

bool loadJsonFile(const QString& filePath)
{
    QFile file(filePath);
    if (!file.open(QIODevice::ReadOnly)) {
        QMessageBox::critical(nullptr, "Errore", "Impossibile aprire il file JSON: " + filePath);
        return false;
    }

    QByteArray Bytes = file.readAll();
    file.close();

    if (Bytes.isEmpty()) {
        QMessageBox::critical(nullptr, "Errore", "Il file JSON è vuoto!");
        return false;
    }

    QJsonParseError JsonError;
    QJsonDocument doc = QJsonDocument::fromJson(Bytes, &JsonError);


    if (JsonError.error != QJsonParseError::NoError) {
        QMessageBox::critical(nullptr, "Errore", "Errore nel parsing JSON: " + JsonError.errorString());
        return false;
    }

    if (!doc.isObject()) {
        QMessageBox::critical(nullptr, "Errore", "Il file JSON non contiene un oggetto valido!");
        return false;
    }


    QJsonObject jsonObj = doc.object();
    for (auto key : jsonObj.keys()) {
        m_mapImgs[key] = jsonObj.value(key).toObject();
    }

    return true;
}

void MainWindow::loadParamsFromJson(const QString& imgKey)
{
    if (!m_mapImgs.contains(imgKey)) {
        QMessageBox::warning(nullptr, "Attenzione", "L'immagine " + imgKey + " non è presente nella mappa!");
        return;
    }

    QJsonObject jsonParams = m_mapImgs[imgKey];

    ui->slr100->setValue(jsonParams["lParam_100"].toInt(100));
    ui->slr101->setValue(jsonParams["lParam_101"].toInt(100));
    ui->slr102->setValue(jsonParams["lParam_102"].toInt(40));
    ui->slr103->setValue(jsonParams["lParam_103"].toInt(50));
    ui->slr104->setValue(jsonParams["lParam_104"].toInt(0));
    ui->slr105->setValue(jsonParams["lParam_105"].toInt(100));
    ui->slr106->setValue(jsonParams["lParam_106"].toInt(50));
    ui->slr107->setValue(jsonParams["lParam_107"].toInt(50));
    ui->slr400->setValue(jsonParams["lParam_400"].toInt(0));
    ui->slr401->setValue(jsonParams["lParam_401"].toInt(0));
    ui->slr402->setValue(jsonParams["lParam_402"].toInt(0));
    ui->slr403->setValue(jsonParams["lParam_403"].toInt(0));
    ui->slr404->setValue(jsonParams["lParam_404"].toInt(0));
    ui->sb209->setValue(jsonParams["lParam_209"].toInt(0));


    ui->lbl100->setText(QString::number(ui->slr100->value()));
    ui->lbl101->setText(QString::number(ui->slr101->value()));
    ui->lbl102->setText(QString::number(ui->slr102->value()));
    ui->lbl103->setText(QString::number(ui->slr103->value()));
    ui->lbl104->setText(QString::number(ui->slr104->value()));
    ui->lbl105->setText(QString::number(ui->slr105->value()));
    ui->lbl106->setText(QString::number(ui->slr106->value()));
    ui->lbl107->setText(QString::number(ui->slr107->value()));
    ui->lbl400->setText(QString::number(ui->slr400->value()));
    ui->lbl401->setText(QString::number(ui->slr401->value()));
    ui->lbl402->setText(QString::number(ui->slr402->value()));
    ui->lbl403->setText(QString::number(ui->slr403->value()));
    ui->lbl404->setText(QString::number(ui->slr404->value()));
    ui->lbl209->setText(QString::number(ui->sb209->value()));

}


MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);

    QString JsonFilePath = getJsonFilePathFromConfig();


    if (loadJsonFile(JsonFilePath)) {

        ui->cbx_category->clear();
        ui->cbx_category->addItems(m_mapImgs.keys());

        int index = ui->cbx_category->findText("_comment");
        if (index != -1) {
            ui->cbx_category->removeItem(index);
        }


        connect(ui->cbx_category, QOverload<int>::of(&QComboBox::currentIndexChanged),
                [this](int index) {
                    QString selectedCategory = ui->cbx_category->itemText(index);
                    loadParamsFromJson(selectedCategory);
                });



        loadParamsFromJson(ui->cbx_category->currentText());



        QVector<QSlider*> sliders = {ui->slr100, ui->slr101, ui->slr102, ui->slr103, ui->slr104, ui->slr105, ui->slr106, ui->slr107,
                                      ui->slr400, ui->slr401, ui->slr402, ui->slr403, ui->slr404};
        QVector<QLabel*> labels = {ui->lbl100, ui->lbl101, ui->lbl102, ui->lbl103, ui->lbl104, ui->lbl105, ui->lbl106, ui->lbl107,
                                    ui->lbl400, ui->lbl401, ui->lbl402, ui->lbl403, ui->lbl404};

        for (int i = 0; i < sliders.size(); ++i) {
            sliders[i]->setRange(0, 100);
        }

        loadParamsFromJson(ui->cbx_category->currentText());
        for (int i = 0; i < sliders.size(); ++i) {
            labels[i]->setText(QString::number(sliders[i]->value()));
        }

        for (int i = 0; i < sliders.size(); ++i) {
            connect(sliders[i], &QSlider::valueChanged, this, [this, i, labels](int value) {
                labels[i]->setText(QString::number(value));
            });
        }


        ui->sb209 -> setRange(0,2);
        ui->lbl209->setText(QString::number(ui->sb209->value()));
        connect(ui->sb209, QOverload<int>::of(&QSpinBox::valueChanged), this, [this](int value) {
            ui->lbl209->setText(QString::number(value));
        });


        connect(ui->btn_save   , &QPushButton::clicked, this, &MainWindow::saveJson);
        connect(ui->btn_annulla, &QPushButton::clicked, this, &MainWindow::annullaJson);
        connect(ui->btn_insert , &QPushButton::clicked, this, &MainWindow::InsertFiltersJson);
        connect(ui->btn_elimina, &QPushButton::clicked, this, &MainWindow::DeleteFiltersJson);
    }
    int iButtonDimension = 50;
    ui->btn_save->setMinimumWidth(iButtonDimension);
    ui->btn_save->setMaximumWidth(iButtonDimension);
    ui->btn_annulla->setMinimumWidth(iButtonDimension);
    ui->btn_annulla->setMaximumWidth(iButtonDimension);

    ui->btn_insert->setMinimumWidth(iButtonDimension);
    ui->btn_insert->setMaximumWidth(iButtonDimension);
    ui->btn_elimina->setMinimumWidth(iButtonDimension);
    ui->btn_elimina->setMaximumWidth(iButtonDimension);


}

void MainWindow::saveJson()
{
    QString JsonFilePath = getJsonFilePathFromConfig();
    QString bakupJsonFilePath = JsonFilePath + ".backup";

    if (!QFile::exists(bakupJsonFilePath)) {
        if (QFile::copy(JsonFilePath, bakupJsonFilePath)) {
            // QMessageBox::information(nullptr, "Successo", "Backup del file JSON creato con successo: " + bakupJsonFilePath);

        } else {
            QMessageBox::critical(nullptr, "Errore", "Errore nel creare il backup del file JSON!");
        }
    } else {
        //QMessageBox::information(nullptr, "Avviso", "Il file di backup esiste già: " + bakupJsonFilePath);
    }

    QFile file(getJsonFilePathFromConfig());

    if (!file.open(QIODevice::ReadOnly)) {
        QMessageBox::critical(this, "Errore", "Errore nell'apertura del file JSON");
        return;
    }

    QByteArray jsonData = file.readAll();
    file.close();

    if (jsonData.isEmpty()) {
        QMessageBox::critical(nullptr, "Errore", "Il file JSON è vuoto!");
        return;
    }


    QJsonDocument doc = QJsonDocument::fromJson(jsonData);
    if (doc.isNull() || !doc.isObject()) {
        QMessageBox::critical(this, "Errore", "Errore nel parsing del JSON");
        return;
    }

    QJsonObject jsonObj = doc.object();
    QString selectedCategory = ui->cbx_category->currentText();

    if (!jsonObj.contains(selectedCategory)) {
        QMessageBox::critical(this, "Errore", "La categoria selezionata non esiste nel JSON!");
        return;
    }


    QJsonObject categoryObj = jsonObj[selectedCategory].toObject();
    categoryObj["lParam_100"] = ui->slr100->value();
    categoryObj["lParam_101"] = ui->slr101->value();
    categoryObj["lParam_102"] = ui->slr102->value();
    categoryObj["lParam_103"] = ui->slr103->value();
    categoryObj["lParam_104"] = ui->slr104->value();
    categoryObj["lParam_105"] = ui->slr105->value();
    categoryObj["lParam_106"] = ui->slr106->value();
    categoryObj["lParam_107"] = ui->slr107->value();

    categoryObj["lParam_400"] = ui->slr400->value();
    categoryObj["lParam_401"] = ui->slr401->value();
    categoryObj["lParam_402"] = ui->slr402->value();
    categoryObj["lParam_403"] = ui->slr403->value();
    categoryObj["lParam_404"] = ui->slr404->value();

    categoryObj["lParam_209"] = ui->sb209->value();


    jsonObj[selectedCategory] = categoryObj;


    if (!file.open(QIODevice::WriteOnly)) {
        QMessageBox::critical(this, "Errore", "Errore nell'apertura del file per scrittura");
        return;
    }

    file.write(QJsonDocument(jsonObj).toJson(QJsonDocument::Indented));
    file.close();


    /* int risposta = QMessageBox::question(
        this, "Aggiornare il backup?",
        "Vuoi aggiornare il file di backup con i nuovi dati?",
        QMessageBox::Yes | QMessageBox::No, QMessageBox::No
        );

    if (risposta == QMessageBox::Yes) {
        QString backupFilePath = getJsonFilePathFromConfig() + ".backup";

        if (QFile::remove(backupFilePath)) {
            if (QFile::copy(getJsonFilePathFromConfig(), backupFilePath)) {
                //QMessageBox::information(nullptr, "Backup aggiornato", "Il backup è stato aggiornato con i nuovi dati.");
            } else {
                QMessageBox::critical(nullptr, "Errore", "Errore nella creazione del nuovo file di backup.");
            }
        } else {
            QMessageBox::critical(nullptr, "Errore", "Errore nella rimozione del file di backup precedente.");
        }
    }*/

}

void MainWindow::annullaJson()
{

    QString JsonFilePath = getJsonFilePathFromConfig();
    QString bakupJsonFilePath = JsonFilePath + ".backup";


    if (!QFile::exists(bakupJsonFilePath)) {
        QMessageBox::critical(this, "Errore", "Il file di backup non esiste!");
        return;
    }


    if (QFile::remove(JsonFilePath)) {
        if (QFile::copy(bakupJsonFilePath, JsonFilePath)) {
            //QMessageBox::information(nullptr, "Successo", "File ripristinato con successo dal backup!");

        } else {
            QMessageBox::critical(this, "Errore", "Errore nel ripristinare il file JSON dal backup!");
            return;
        }
    } else {
        QMessageBox::critical(this, "Errore", "Errore nell'eliminare il file originale!");
        return;
    }



    if (loadJsonFile(JsonFilePath)) {
        QString selectedCategory = ui->cbx_category->currentText();
        loadParamsFromJson(selectedCategory);
    } else {
        QMessageBox::critical(nullptr, "Errore", "Errore nel caricare il file JSON ripristinato!");
    }

}

void MainWindow::InsertFiltersJson()
{


    QString selectedCategory = ui->cbx_category->currentText();

    if (selectedCategory.isEmpty()) {
        QMessageBox::warning(this, "Attenzione", "Seleziona una categoria per creare una copia!");
        return;
    }


    QString newCategory = selectedCategory;
    int copyCount = 1;


    while (m_mapImgs.contains(newCategory)) {
        newCategory = selectedCategory + QString("*").repeated(copyCount);
        copyCount++;
    }


    QJsonObject copiedCategory = m_mapImgs[selectedCategory];


    m_mapImgs[newCategory] = copiedCategory;


    ui->cbx_category->addItem(newCategory);
    ui->cbx_category->setCurrentText(newCategory);


    loadParamsFromJson(newCategory);


    QString JsonFilePath = getJsonFilePathFromConfig();
    QFile file(JsonFilePath);

    if (!file.open(QIODevice::ReadOnly)) {
        QMessageBox::critical(this, "Errore", "Errore nell'aprire il file JSON per la lettura");
        return;
    }

    QByteArray jsonData = file.readAll();
    file.close();

    if (jsonData.isEmpty()) {
        QMessageBox::critical(nullptr, "Errore", "Il file JSON è vuoto!");
        return;
    }

    QJsonDocument doc = QJsonDocument::fromJson(jsonData);
    if (doc.isNull() || !doc.isObject()) {
        QMessageBox::critical(this, "Errore", "Errore nel parsing del JSON");
        return;
    }

    QJsonObject jsonObj = doc.object();


    jsonObj[newCategory] = copiedCategory;


    if (!file.open(QIODevice::WriteOnly)) {
        QMessageBox::critical(this, "Errore", "Errore nell'aprire il file JSON per la scrittura");
        return;
    }

    file.write(QJsonDocument(jsonObj).toJson(QJsonDocument::Indented));
    file.close();

    QString bakupJsonFilePath = JsonFilePath + ".backup";
    QFile backupFile(bakupJsonFilePath);


    if (!backupFile.open(QIODevice::ReadOnly)) {
        QMessageBox::critical(this, "Errore", "Errore nell'aprire il file di backup JSON per la lettura");
        return;
    }

    QByteArray backupJsonData = backupFile.readAll();
    backupFile.close();

    if (backupJsonData.isEmpty()) {
        QMessageBox::critical(nullptr, "Errore", "Il file di backup JSON è vuoto!");
        return;
    }

    QJsonDocument backupDoc = QJsonDocument::fromJson(backupJsonData);
    if (backupDoc.isNull() || !backupDoc.isObject()) {
        QMessageBox::critical(this, "Errore", "Errore nel parsing del file di backup JSON");
        return;
    }

    QJsonObject backupJsonObj = backupDoc.object();


    backupJsonObj[newCategory] = copiedCategory;


    if (!backupFile.open(QIODevice::WriteOnly)) {
        QMessageBox::critical(this, "Errore", "Errore nell'aprire il file di backup JSON per la scrittura");
        return;
    }

    backupFile.write(QJsonDocument(backupJsonObj).toJson(QJsonDocument::Indented));
    backupFile.close();


}

void MainWindow::DeleteFiltersJson()
{
    QString selectedCategory = ui->cbx_category->currentText();

    if (selectedCategory.isEmpty()) {
        QMessageBox::warning(this, "Attenzione", "Seleziona una categoria da eliminare!");
        return;
    }

    int risposta = QMessageBox::question(
        this, "Conferma eliminazione",
        "Sei sicuro di voler eliminare la categoria '" + selectedCategory + "'?",
        QMessageBox::Yes | QMessageBox::No, QMessageBox::No
        );

    if (risposta == QMessageBox::No) {
        return;
    }

    if (!m_mapImgs.remove(selectedCategory)) {
        QMessageBox::warning(this, "Errore", "La categoria selezionata non è presente nella mappa.");
        return;
    }

    int index = ui->cbx_category->findText(selectedCategory);
    if (index != -1) {
        ui->cbx_category->removeItem(index);
    }


    QString JsonFilePath = getJsonFilePathFromConfig();
    QFile file(JsonFilePath);

    if (!file.open(QIODevice::ReadOnly)) {
        QMessageBox::critical(this, "Errore", "Errore nell'apertura del file JSON per la lettura");
        return;
    }

    QByteArray jsonData = file.readAll();
    file.close();

    if (jsonData.isEmpty()) {
        QMessageBox::critical(nullptr, "Errore", "Il file JSON è vuoto!");
        return;
    }

    QJsonDocument doc = QJsonDocument::fromJson(jsonData);
    if (doc.isNull() || !doc.isObject()) {
        QMessageBox::critical(this, "Errore", "Errore nel parsing del JSON");
        return;
    }

    QJsonObject jsonObj = doc.object();

    if (!jsonObj.contains(selectedCategory)) {
        QMessageBox::critical(this, "Errore", "La categoria selezionata non esiste nel JSON!");
        return;
    }

    jsonObj.remove(selectedCategory);


    if (!file.open(QIODevice::WriteOnly)) {
        QMessageBox::critical(this, "Errore", "Errore nell'apertura del file JSON per la scrittura");
        return;
    }

    file.write(QJsonDocument(jsonObj).toJson(QJsonDocument::Indented));
    file.close();




    if (ui->cbx_category->count() > 0) {
        ui->cbx_category->setCurrentIndex(0);
        loadParamsFromJson(ui->cbx_category->currentText());
    } else {
        QMessageBox::information(this, "Informazione", "Non ci sono più categorie disponibili.");
    }
}





MainWindow::~MainWindow()
{
    delete ui;
}



