#include "dialog.h"
#include "ui_dialog.h"
#include <QMessageBox>

Dialog::Dialog(QWidget *parent)
    : QDialog(parent)
    , ui(new Ui::Dialog)
{
    ui->setupUi(this);
}

Dialog::~Dialog()
{
    delete ui;
}


void Dialog::on_btn_enter_clicked()
{
    QString username = ui -> lineEdit_Username -> text();
    QString password = ui -> lineEdit_Password -> text();

    if(password == "Master"){
        accept();
    }
    else {
        QMessageBox::warning(this, "login", "password is not correct");
    }
}
