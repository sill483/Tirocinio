
#include "mainwindow.h"
#include "dialog.h"
#include <QApplication>

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);

    Dialog login;
    login.setWindowTitle("SingIn");
    if (login.exec() == QDialog::Accepted) {

        MainWindow w;
        w.setWindowTitle("LUT");
        w.show();
        return a.exec();
    }

    return 0;
}
